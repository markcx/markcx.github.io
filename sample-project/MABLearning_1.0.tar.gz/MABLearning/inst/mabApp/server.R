library(shiny)
library(ggplot2)
library(parallel)
# source("../../R/Bandit.R")
# source("../../R/banditSimulation.R")
# source("../../R/epsGreedy.R")
# source("../../R/ucb.R")
# source("../../R/thompsonSampling.R")

# Define server logic required to plot various variables against horizon steps
shinyServer(function(input, output) {

  require(MABLearning)
  # Generate a plot of the percent of optimal action against time horizon
  # requested variable
  # ggplot version

  output$simulationPlot <- renderPlot({
    # check for the input variable
    STEP_HORIZON = 300
    if (input$variable == "eps") {
      resSim <- MABLearning::epsGreedy(steps = STEP_HORIZON)  # run eps-greedy
    }
    else if (input$variable == "ucb") {
      resSim <- MABLearning::ucb(steps = STEP_HORIZON)  # run ucb
    } else {
      resSim <- MABLearning::thompsonSampling(steps = STEP_HORIZON) # run thompson sampling
    }

    df = data.frame( step = c(1:STEP_HORIZON) ,
                     optActPct1 = resSim$bestActionCounts)

    p <- ggplot(df, aes(x=step, y=optActPct1)) +
      geom_line() + ylim(0, 1-1e-3) +
      ylab("% optimal action")  + xlab("steps") +
      theme_bw() + ggtitle(input$variable)
    print(p)
  })

})

