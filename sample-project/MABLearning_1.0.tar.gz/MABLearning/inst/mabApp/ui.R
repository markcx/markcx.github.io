library(shiny)
shinyUI(fluidPage( pageWithSidebar(

  # Application title
  headerPanel("Multi-armed Bandit Learning"),

  # Sidebar with controls to select the variable to plot against steps
  sidebarPanel(
    selectInput("variable", "Bandit Learning Algorithm:",
                list("Eps-Greedy" = "eps",
                     "UCB" = "ucb",
                     "Thompson Sampling" = "ts"))

  ),

  mainPanel(plotOutput("simulationPlot"))
  ) )
)
