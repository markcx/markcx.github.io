## ---- eval=FALSE---------------------------------------------------------
#  library(MABLearning)
#  library(parallel)
#  # an example of calling default epsGreedy function
#  run.eps.res1 <- MABLearning::epsGreedy()

## ---- eval=FALSE---------------------------------------------------------
#  run.eps.res2 <- MABLearning::epsGreedy(nBandits = 200, steps = 1000, eps = 0.05 )
#  run.eps.res3 <- MABLearning::epsGreedy(nBandits = 200, steps = 1000, eps = 0.2 )
#  

## ---- eval=FALSE---------------------------------------------------------
#  # an example of calling default ucb function
#  run.ucb.res1 <- MABLearning::ucb()
#  

## ---- eval=FALSE---------------------------------------------------------
#  run.ucb.res2 <- MABLearning::ucb(nBandits = 200, steps = 1000, ucbParam = 1)
#  run.ucb.res3 <- MABLearning::ucb(nBandits = 400, steps = 1000, ucbParam = 2)

## ---- eval=FALSE---------------------------------------------------------
#  run.ts.res1 <- MABLearning::thompsonSampling()

## ---- eval=FALSE---------------------------------------------------------
#  run.rs.res2 <- MABLearning::thompsonSampling(nBandits = 400, steps = 1000, TSpDist = "normal" )

