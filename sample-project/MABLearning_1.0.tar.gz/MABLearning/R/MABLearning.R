#' Stat 290 Multi-armed Bandit Learning Package
#'
#' \code{MABLearning} is a simple package for
#' stat290 final project and potential future research. It provides three wrapper functions
#' \code{epsGreedy}, \code{ucb} and \code{thompsonSampling} in addition to a sample shinny App
#'
#'
#' @seealso \code{espGreedy}
#' @seealso \code{ucb}
#' @seealso \code{thompsonSampling}
#' @useDynLib MABLearning
#' @importFrom parallel mclapply
#' @importFrom MASS mvrnorm
#' @importFrom utils globalVariables
#' @docType package
#' @name MABLearning
NULL

utils::globalVariables(names = c("epsGreedy",
                                 "MASS",
                                 "ggplot2",
                                 "parallel",
                                 "stats",
                                 "ucb",
                                 "thompsonSampling"))

