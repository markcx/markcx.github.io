#' Create a wrapper function to run UCB algorithm
#'
#' @description The function gives a simple way to call for testing the
#' Upper Confidence Bound algorithm.
#'
#' @param nBandits number of Bandit agents
#' @param steps number of bandit learning horizon steps
#' @param ucbParam numeric value of the tunning parameter of coefficient
#' of confidence bound
#'
#'
#' @export
#'
#' @importFrom parallel mclapply
#'
#' @examples
#' library(parallel)
#' ucb(steps = 400,  ucbParam = 1)
#'
#' @keywords ucb
#'
ucb <- function(nBandits=300, steps=500, ucbParam=2 ) {
  bandits = parallel::mclapply(seq(nBandits), function(i) {
    banditInst =  Bandit$new(kArm=10, epsilon=0, initial=1, UCBParam=ucbParam, sampleAverage=TRUE )
    banditInst$addRewardNoise(rewardNoise = expression(rnorm(1, mean = 2, sd=1)))
    return(banditInst)
  })
  res <- banditSimulation(nBandits, steps, bandits)
  return(res)
}
