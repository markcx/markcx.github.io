#' Create a wrapper function to run Thompson Sampling algorithm
#'
#' @description The function gives a simple way to call for testing the
#' Thompson Sampling algorithm.
#'
#' @param nBandits number of Bandit agents
#' @param steps number of bandit learning horizon steps
#' @param TSpDist characters describing Thompson Sampling posterior probability distribution
#' family name; currently it accepts `normal` or `gaussian`
#'
#'
#' @export
#'
#' @importFrom parallel mclapply
#' @importFrom MASS mvrnorm
#'
#' @examples
#' library(parallel)
#' library(MASS)
#' thompsonSampling(steps = 400 )
#'
#' @keywords Thompson Sampling
#'
thompsonSampling <- function(nBandits=300, steps=500, TSpDist="normal" ) {
  bandits = parallel::mclapply(seq(nBandits), function(i) {
    banditInst =  Bandit$new(kArm=10, epsilon=0, initial=1, TSposterior=TSpDist, sampleAverage=TRUE ) # sampleAverage=TRUE
    banditInst$addRewardNoise(rewardNoise = expression(rnorm(1, mean = 2, sd=1)))
    return(banditInst)
  })
  res <- banditSimulation(nBandits, steps, bandits)
  return(res)
}
