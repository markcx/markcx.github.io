#' Generate simulation for Bandit learning
#'
#' @description the function run the simulation, taking the number of Bandit Agents,
#' number of horizon steps, and list of bandits instances (R6 Class instance)
#' @param nBandits the number of Bandit Agents
#' @param steps the learning horizon steps
#' @param bandits a list of Bandit instances (R6 Class instances)
#' @return a list consisting two fields (\code{bestActionCounts}, \code{averageRewards})
#'
#' @export
#'
#' @importFrom R6 R6Class
#' @importFrom stats rnorm
#'
#' @examples
#'
#' library(parallel)
#'
#' epsGreedy <- function(nBandits=300, steps=500, eps = 0.1 ){
#'   bandits = mclapply(seq(nBandits), function(i) {
#'     banditInst = Bandit$new(kArm=10, epsilon=eps, sampleAverage=TRUE)
#'     banditInst$addRewardNoise(rewardNoise = expression(rnorm(1, mean = 2, sd=1)))
#'     return(banditInst) }  )
#'   res <- banditSimulation(nBandits, steps, bandits)
#'  return(res)
#' }
#'
#' @keywords banditSimulation
#'
banditSimulation <- function(nBandits, steps, bandits){
  bestActionCounts = rep(0, steps)
  averageRewards = rep(0, steps)

  for (i in c(1:nBandits)) {
    #
    for (t in c(1:steps)){
      action = bandits[[i]]$getAction()
      reward = bandits[[i]]$takeAction(action=action, rewardNoise = expression(rnorm(1, mean=0, sd=1)))
      averageRewards[t] = averageRewards[t] + reward
      if (action == bandits[[i]]$bestAction() ){
        bestActionCounts[t] = bestActionCounts[t] + 1
      }

    }# end for-loop of steps

  }# end for-loop of nBandits
  bestActionCounts = bestActionCounts/nBandits
  averageRewards = averageRewards/nBandits

  return(list(bestActionCounts = bestActionCounts,
              averageRewards = averageRewards ))
}

