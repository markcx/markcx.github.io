#' Create a wrapper function to run epsilon greedy
#'
#' @description The function gives a simple way to call for testing the
#' epsilon greedy algorithm.
#'
#' @param nBandits number of Bandit agents
#' @param steps number of bandit learning horizon steps
#' @param eps the tunning parameter (probability) that can be adjusted for
#' exploring the other non-best actions
#'
#' @export
#'
#' @importFrom parallel mclapply
#'
#' @examples
#' library(parallel)
#' epsGreedy(steps = 400, eps = 0.01)
#'
#' @keywords epsGreedy
#'
epsGreedy <- function(nBandits=300, steps=500, eps = 0.1 ){
  bandits = parallel::mclapply(seq(nBandits), function(i) {
    banditInst = Bandit$new(kArm=10, epsilon=eps, initial=1, sampleAverage=TRUE)
    banditInst$addRewardNoise(rewardNoise = expression(rnorm(1, mean = 2, sd=1)))
    return(banditInst) }  )
  res <- banditSimulation(nBandits, steps, bandits)
  return(res)
}
