#' Create a \code{Bandit} object with data or random data (default)
#'
#' @description \code{Bandit} is an object that the Bandit Agent can make
#' decision and choose the best action/arm.
#' A Bandit consists of multiple fields and can pick the best action according
#' to different algorithm depending on the instantiation of the instance.
#'
#' @docType class
#' @importFrom R6 R6Class
#' @importFrom ggplot2 ggplot
#' @importFrom stats rnorm
#' @importFrom MASS mvrnorm
#'
#' @field kArm the number of arms that a Bandit agent need to choose
#' from as a numeric scalar.
#' @field epsilon the parameter that epsilon greedy algorithm will use.
#' It should be greater than 0 (if using eps-greedy algorithm) or
#' equal to 0 if UCB or TS algorithm are chosen. It should be a
#' numeric scalar.
#' @field initial the initial value/reward for choosing each action/arm.
#' Supposing they are the same at our inital guessing in this simulation
#' setting. It is a numeric scalar and it takes 0 by default.
#' @field stepSize the constant step size for updating estimations.
#' @field sampleAverage if True, use sample averages to update estimations
#' instead of constant step size.
#' @field UCBparam if not NA and greater than 0, use UCB algorithm to
#' select action
#' @field TSposterior the keyword that describe the distribution family;
#' currently it takes characters of "normal" or "gaussian" only.
#' @field gradient if True, use gradient based bandit algorithm (To be
#' implemented soon)
#' @field gradientBaseline if True, use average reward as baseline for
#' gradient based bandit algorithm (To be implemented soon)
#' @field trueReward the reward in reality if it is known. It is zero by default
#'
#' @section Methods:
#'
#' \describe{
#'   \item{\code{Bandit$new(kArm, epsilon=0.1, sampleAverage=TRUE)}}{Creates a new \code{Bandit}
#'         called with specified algorithm. Default arm number is 10
#'         and default reward is 0.}
#'   \item{\code{addRewardNoise(expression)}}{Adds the noise to value of true rewards.}
#'   \item{\code{bestAction()}}{Returns the best action or best arm according to true value.}
#'   \item{\code{getAction()}}{Returns the what action has been chosen according to estimation.}
#'   \item{\code{takeAction(action, rewardnoise)}}{Returns the reward associated with taking an action.}
#' }
#'
#'
#' @examples
#' Bandit$new(kArm=10, epsilon=0.1, sampleAverage=TRUE)
#'
#' banditInst = Bandit$new(kArm=10, epsilon=0, initial=5, UCBParam=2, sampleAverage=TRUE )
#' banditInst$addRewardNoise(rewardNoise = expression(rnorm(1, mean = 2, sd=1)))
#'
#' @export
#' @format An \code{R6Class} generator object
#'
#'
#' library(R6)
#'
Bandit <- R6::R6Class("Bandit",
                      private = list(kArm = 10,
                                     epsilon = 0,
                                     initial = 0,
                                     stepSize = 0.1,
                                     sampleAverage = FALSE,
                                     UCBParam = NA,
                                     TSpDist = NA,
                                     gradient = NA,
                                     gradientBaseline=NA,
                                     trueReward = 0,
                                     # --- constructor pass in vars ended ---
                                     qTrue = NA, # real reward for each action
                                     qEst = NA,  # estimate reward for each action
                                     action_cnt = NA, # actions counts
                                     #
                                     averageReward = 0,
                                     rewardNoise = NA,
                                     bestAction_ = NA,  # var_ is internal used variables
                                     indices = NA,
                                     step_ = 0,
                                     tsSigma = NA # Thompson Sampling internal usage
                      ), # end of private
                      public = list(
                        initialize=function(kArm = 10,
                                            epsilon = 0,
                                            initial = 0,
                                            stepSize = 0.1,
                                            sampleAverage = FALSE,
                                            UCBParam = NA,
                                            TSposterior = NA,
                                            gradient = NA,
                                            gradientBaseline=NA,
                                            trueReward = 0) {
                          private$kArm = kArm   # param
                          private$epsilon = epsilon # param
                          private$initial = initial # param
                          private$stepSize = stepSize # param
                          private$sampleAverage = sampleAverage # param
                          private$UCBParam = UCBParam  # param
                          private$TSpDist = TSposterior   # param
                          private$gradient = gradient  # param
                          private$gradientBaseline = gradientBaseline # param
                          private$trueReward = trueReward   # param
                          private$averageReward = 0
                          private$indices = seq(private$kArm)
                          private$step_ = 0
                          #
                          private$qTrue = rep(trueReward, kArm)  # real reward for each action
                          private$qEst = rep(initial, kArm)      # estimate reward for each action
                          private$action_cnt = rep(0, kArm)
                          # initialize real rewards with random noize - N(0,1) by default
                          private$tsSigma = NA
                        }, # end of initialize function (constructor)
                        #
                        addRewardNoise = function(rewardNoise=expression(0)){
                          if (length(eval(rewardNoise)) == 1) {
                            private$qTrue = sapply(private$indices, function(i) {
                              private$qTrue[i] + eval(rewardNoise) } )
                          } else if (length(eval(rewardNoise)) == private$kArm) {
                            private$qTrue == private$qTrue + eval(rewardNoise)
                          } else {
                            stop("Incorrect input -- Please input a expression generate a scalar or kArm-length vector")
                          }
                          # bestAction = which.max(private$qTrue)
                          private$bestAction_ = which.max(private$qTrue)
                        },
                        # best action function
                        bestAction = function(){ return(private$bestAction_) } , # internal call
                        # get action function
                        getAction = function(){
                          # eps greedy
                          if (private$epsilon > 0 ) {
                            if (rbinom(1, 1, private$epsilon) == 1) {
                              private$indices = sample(private$indices)
                              return(private$indices[1])
                            }
                          }
                          # UCB
                          if ((!is.na(private$UCBParam)) & (private$UCBParam > 0) ) {
                            # browser()
                            UCBEst = private$qEst + private$UCBParam * sqrt(log(private$step_ +1)/(private$action_cnt + 1))
                            return(which.max(UCBEst))
                          }
                          # Thompson Sampling
                          if (!is.na(private$TSpDist)) {

                            if (( private$TSpDist == "normal") || (private$TSpDist == "gaussian") ){
                              if (private$step_ <= 1) {
                                private$tsSigma = diag(1, nrow = private$kArm, ncol = private$kArm )
                                tsMu = private$qEst  # tsMu : Thompson Sampling mean
                              } else {
                                action_ = which.max(private$qEst)
                                private$tsSigma[action_, action_] = 1 / (private$action_cnt[action_] + 1)
                                tsMu = MASS::mvrnorm(n=1, mu=private$qEst, Sigma = private$tsSigma )
                              }
                              return(which.max(tsMu))
                            }

                          }

                          return(which.max(private$qEst))
                        },
                        # take action function
                        takeAction = function(action=NULL, rewardNoise=expression(0) ){
                          if (is.null(action)) { stop("Error -- Please define the action") }
                          #
                          reward = private$qTrue[action] + eval(rewardNoise)
                          private$step_ = private$step_ + 1
                          private$averageReward = (private$step_ - 1 ) / private$step_ * private$averageReward + reward/private$step_
                          private$action_cnt[action] = private$action_cnt[action] + 1
                          #
                          if (private$sampleAverage == TRUE ) {
                            private$qEst[action] = private$qEst[action] + 1 / private$action_cnt[action] * (reward - private$qEst[action])
                          }
                          return(reward)
                        }
                      ) # end of public

) # end of R6 class
