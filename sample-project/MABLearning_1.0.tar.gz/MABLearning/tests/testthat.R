library(testthat)
library(MABLearning)

test_check("MABLearning")
