library(parallel)


res <- ucb(nBandits = 100, steps = 200, ucbParam = 1)
expect_equal("bestActionCounts", names(res)[1])
expect_equal("averageRewards", names(res)[2])
expect_equal(200, length(res[[1]]))
expect_equal(200, length(res[[2]]))